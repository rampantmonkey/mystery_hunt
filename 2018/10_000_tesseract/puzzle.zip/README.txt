The puzzle directory consists of 10000 puzzles, each with a one-word answer.  We have also included a dictionary that should be used for the purposes of this puzzle and some examples for further clarification.

The puzzle nomenclature is as follows: puzzle0000.txt is the UP, LEFT, FRONT, and ANA-most puzzle, with the four digits corresponding, in order, to these directions.  Thus, puzzle9090.txt is the DOWN, LEFT, BACK, and ANA-most puzzle, and puzzle9999.txt is the DOWN, RIGHT, BACK, and KATA-most puzzle.  
